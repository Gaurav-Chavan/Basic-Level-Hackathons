################################# Install Necessary Packages ############################
setwd("C:/Users/acer/Desktop/Capgemini Challenge/Data Sic/Finale Challenge/code/X-RayClassification/X-Ray Classification/dataset/dataset/normal")


source("http://bioconductor.org/biocLite.R")
biocLite()
biocLite("EBImage")

library(EBImage)




#  Input Dircetories for Normal and Abnormal Images

image_dir1 <- "C:/Users/acer/Desktop/Capgemini Challenge/Data Sic/Finale Challenge/code/X-RayClassification/X-Ray Classification/dataset/dataset/normal"
image_dir2 <- "C:/Users/acer/Desktop/Capgemini Challenge/Data Sic/Finale Challenge/code/X-RayClassification/X-Ray Classification/dataset/dataset/abnormal"

# List images in path
images_names_normal <- list.files(image_dir1)
images_names_abnormal <- list.files(image_dir2)

############# Varaibles Assignment #######################
add_label=T
is_normal=T
width <- 28
height <- 28


## Set label For normal = 0, abnormal = 1

######################### Create Normal Images Feature #####################################

normal_feature_matrix<-as.data.frame(matrix(nrow =2352,ncol=101 ))

for ( i in 1:length(images_names_normal))
{
  img_vector<-c()
  # Read image
      img <- readImage(file.path(image_dir1, images_names_normal[i]))
      ## Resize image
      img_resized <- resize(img, w = width, h = height)
  #     ## Get the image as a matrix
      img_matrix <- img_resized@.Data
      
       img_vector <- as.vector((img_matrix))
       normal_feature_matrix[,i] <- img_vector
       
}  
names(normal_feature_matrix)<-paste0("image", c(1:ncol(normal_feature_matrix)))
normal_feature_matrix <- cbind(label = 0, normal_feature_matrix)


################################# Create abnormal Images Features #######################################
abnormal_feature_matrix<-as.data.frame(matrix(nrow =2352,ncol=123 ))
for ( i in 1:length(images_names_abnormal))
{
  img_vector<-c()
  # Read image
  img <- readImage(file.path(image_dir2, images_names_abnormal[i]))
  ## Resize image
  img_resized <- resize(img, w = width, h = height)
  #     ## Get the image as a matrix
  img_matrix <- img_resized@.Data

  img_vector <- as.vector((img_matrix))
  abnormal_feature_matrix[,i] <- img_vector
  
}  
names(abnormal_feature_matrix)<-paste0("image", c(1:ncol(abnormal_feature_matrix)))
abnormal_feature_matrix <- cbind(label = 1, abnormal_feature_matrix)

normal_data<-normal_feature_matrix
abnormal_data<-abnormal_feature_matrix


################################### Data Science #######################################

library(caret)
################################add coulmns to normal data ################################3
normal_data[setdiff(names(abnormal_data), names(normal_data))] <- NA


## Bind rows in a single dataset
complete_set <- rbind(normal_data,abnormal_data)

##################Impute Missing Values #############################

library(e1071)
complete_set<-impute(complete_set,what="mean")
unique(is.na(complete_set))

complete_set<-as.data.frame(complete_set)
str(complete_set)

# ##################### All values are numeric so  we can use Principal Component Analysis 
#                       For Dimensionality Reduction

my_data <- subset(complete_set, select = -c(label))
a<-dim(my_data)

accuracy_glm<-as.data.frame(matrix(nrow=4,ncol=1))
accuracy_rf<-as.data.frame(matrix(nrow=4,ncol=1))
accuracy_nb<-as.data.frame(matrix(nrow=4,ncol=1))
accuracy_rpart<-as.data.frame(matrix(nrow=4,ncol=1))
accuracy_svm<-as.data.frame(matrix(nrow=4,ncol=1))

#remove the identifier variables
l<-1

for (j in 6:9)
{
a<-dim(my_data)
temp<-j/10
b<-round((a[1]*temp),0)

#divide the new data
pca.train <- my_data[1:b,]
pca.test <- my_data[-(1:b),]

#principal component analysis
prin_comp <- prcomp(pca.train, scale. = T)
names(prin_comp)

dim(prin_comp$x)

# # Let's plot the resultant principal components.
# biplot(prin_comp, scale = 0)

#compute standard deviation of each principal component
std_dev <- prin_comp$sdev

#compute variance
pr_var <- std_dev^2

#proportion of variance explained
prop_varex <- pr_var/sum(pr_var)
sum(prop_varex[1:30])

#add a training set with principal components
label<- as.factor(complete_set$label)

#the order will remain the same i.e. 'normal' for '0' and 'abnormal' for '1'
levels(label) <- c('normal', 'abnormal')
train.data <- data.frame(labels = label[1:b], prin_comp$x)

#we are interested in first 30 PCAs
train.data <- train.data[,1:31]
head(train.data)

#transform test into PCA
test.data <- predict(prin_comp, newdata = pca.test)
test.data <- as.data.frame(test.data)

#select the first 30 components
test.data <- test.data[,1:30]

################################ actual values ###################
actual<-label[-(1:b)] 

############################### glm   model ######################################################
ctrl <- trainControl(method="cv",summaryFunction = twoClassSummary,classProbs=TRUE,savePredictions =TRUE)
glm_fit <- train(labels ~ .,data = train.data,method = "glm", metric = "Accuracy", trControl = ctrl)

predict_glm<-predict(glm_fit,newdata =test.data)



#################confusion matrix ###########################
confusion_m_glm<-confusionMatrix(data =predict_glm,reference=actual)

##############Compute Accuracy ##########################
accuracy_glm$V1[l]<-confusion_m_glm$overall["Accuracy"]


############################# Random Forest Model ####################################################33

rf_fit <- train(labels ~ .,data = train.data,method = "rf", metric = "Accuracy", trControl = ctrl)
predict_rf<-predict(rf_fit,newdata =test.data )

confusion_m_rf<-confusionMatrix(data =predict_rf,reference=actual)
accuracy_rf$V1[l]<-confusion_m_rf$overall["Accuracy"]




########################### NAIVE bayes Classifier ############################
nb_fit <- train(labels ~ .,data = train.data,method = "nb", metric = "Accuracy", trControl = ctrl)
predict_nb<-predict(nb_fit,newdata =test.data )

confusion_m_nb<-confusionMatrix(data =predict_nb,reference=actual)
accuracy_nb$V1[l]<-confusion_m_nb$overall["Accuracy"]


########################### Decision Tree  Classifier ############################
rpart_fit <- train(labels ~ .,data = train.data,method = "rpart", metric = "Accuracy", trControl = ctrl)
predict_rpart<-predict(rpart_fit,newdata =test.data )

confusion_m_rpart<-confusionMatrix(data =predict_rpart,reference=actual)
accuracy_rpart$V1[l]<-confusion_m_rpart$overall["Accuracy"]





############################ SVM Model #####################################################
library(e1071)
svm_fit<-svm(labels ~ ., data=train.data)
summary(svm_fit)
predict_svm<-predict(svm_fit,newdata =test.data )

confusion_m_svm<-confusionMatrix(data =predict_svm,reference=actual)
accuracy_svm$V1[l]<-confusion_m_svm$overall["Accuracy"]

l<-l+1
}

########################## BARPLOT  #############################
counts <- cbind(accuracy_glm,accuracy_rf,accuracy_nb,accuracy_rpart,accuracy_svm)
colnames(counts)<-c("GLM","Random Forest","Naive Bayes","Decision Tree","SVM")
counts1<-as.matrix(counts)
rownames(counts1)<-c("60%","70%","80%","90%")
barplot(counts1, main="Accuracy  Distribution of algorithms according to 60:70:80:90 training samples",
        xlab="Training Samples 60% 70% 80% 90% ",ylab="Time in Seconds", col=c("darkblue","red","yellow","green"),
        legend= rownames(counts1),beside=TRUE)
