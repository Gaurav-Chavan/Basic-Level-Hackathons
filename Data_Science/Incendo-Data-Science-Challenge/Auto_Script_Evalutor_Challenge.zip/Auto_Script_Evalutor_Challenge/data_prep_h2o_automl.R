#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#xxxxxxxxxxxxxxxxxx Import Libraries and set path xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Install Missing Packages Autoamtically.
list.of.packages <- c("data.table","ggthemes","SnowballC","lubridate", "readxl","h2o","mice","VIM","Hmisc","dplyr","caret","tidyr","stringr","corrplot","reshape","tidyverse","tm","topicmodels")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)


# Load Libraries
library(h2o) # for data modelling
library(mice)  #Missing Values Imputation 
library(VIM) #plotting
library(Hmisc) # Imputing Missing Values
library(caret)  # For ML operations
library(tidyr) # for cleaning data
library(stringr) # for cleaning text data
library(corrplot) # for correlation plotting
library(reshape)  # for reshaping dataframes



# read in the libraries we're going to use
library(tidyverse) # general utility & workflow functions
library(tidytext) # tidy implimentation of NLP methods
library(topicmodels) # for LDA topic modelling
library(tm) # general text mining functions, making document term matrixes
library(SnowballC) # for stemming

library(data.table)
library(ggplot2)
library(ggthemes)



setwd("~/Incendo/02")


# Import Train, Test, Sample SUbmission  files


train <- read.csv("train_dataset.csv", na.strings="",stringsAsFactors = F)

test <- read.csv("test_dataset.csv", na.strings="",stringsAsFactors = F)



#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


#xxxxxxxxxxxxx Data Preparation  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


# Get summary of training data
summary(train)
str(train)

colSums(is.na(train))



#-------------------- Impute Missing Values ---------------------#

#== For score_3

# impute with mean  value
temp1 <- with(train, impute(score_3, mean))

write.csv(temp1,"temp1.csv",row.names = F)

temp1 <- read.csv("temp1.csv",stringsAsFactors = T)

train$score_3 <- temp1$x

#== FOr score_4
temp1 <- with(train, impute(score_4, mean))

write.csv(temp1,"temp1.csv",row.names = F)

temp1 <- read.csv("temp1.csv",stringsAsFactors = T)

train$score_4 <- temp1$x

#== FOr score_5
temp1 <- with(train, impute(score_5, mean))

write.csv(temp1,"temp1.csv",row.names = F)

temp1 <- read.csv("temp1.csv",stringsAsFactors = T)

train$score_5 <- temp1$x

#== FOr clarity
temp1 <- with(train, impute(clarity, mode))

write.csv(temp1,"temp1.csv",row.names = F)

temp1 <- read.csv("temp1.csv",stringsAsFactors = T)

train$clarity <- temp1$x


#== FOr coherent
temp1 <- with(train, impute(coherent, mode))

write.csv(temp1,"temp1.csv",row.names = F)

temp1 <- read.csv("temp1.csv",stringsAsFactors = T)

train$coherent <- temp1$x




#--- FOr Essay Set remove the missing data. (Rows containing no values.) -------------#

temp1 <- train[is.na(train$Essayset),]

train <- train[complete.cases(train),]

rm(temp1)



#-------------------- Get Average Score and store it in variable essay_score ----------#

train$essay_score <- round(rowMeans(train[,5:9]),digits = 2)

train$score_1 <- NULL
train$score_2 <- NULL
train$score_3 <-  NULL
train$score_4 <- NULL
train$score_5 <- NULL



#------------------------- Create a Corpus Data set -------------------------------------#
temp1 <- as.data.frame(train$EssayText)
temp2 <- as.data.frame(test$EssayText)

colnames(temp1)[1] <- "EssayText"
colnames(temp2)[1] <- "EssayText"


temp <- rbind(temp1,temp2)

rm(temp1, temp2)


#------------- Merge train and test set --------------------#

essay_score <- train$essay_score
train$essay_score <- NULL

data <- rbind(train,test)


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


#xxxxxxxxxxxxx Natural Language Processing  xxxxxxxxxxxxxxxxxxx#


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



Corpus_data <- VCorpus(VectorSource(temp$EssayText))
 

 ##------------- Removing Punctuation  --------------------#
Corpus_data <- tm_map(Corpus_data, content_transformer(removePunctuation))

 ##------------- Removing numbers  --------------------#
  Corpus_data <- tm_map(Corpus_data, removeNumbers)

   ##------------- Converting to lower case  --------------------#
  Corpus_data <- tm_map(Corpus_data, content_transformer(tolower))

 ##------------- Removing stop words  --------------------#
  Corpus_data <- tm_map(Corpus_data, content_transformer(removeWords), stopwords("english"))

 ##------------- Stemming  --------------------#
  Corpus_data <- tm_map(Corpus_data, stemDocument)

 ##------------- Whitespace  --------------------#
  Corpus_data <- tm_map(Corpus_data, stripWhitespace)
 
 # #-------------  Create Document Term Matrix  --------------------#
  dtm_data <- DocumentTermMatrix(Corpus_data)
   

  # #-------------  Sparse Term Removal  --------------------#  
 dtm_data_corpus <- removeSparseTerms(dtm_data, 0.95)
 
 
 # #-------------  Word Count Distribution   --------------------#  
 colS <- colSums(as.matrix(dtm_data_corpus))
 doc_features <- data.table(name = attributes(colS)$names, count = colS)
 ggplot(doc_features[count>2000],aes(name, count)) + geom_bar(stat = "identity",fill='lightblue',color='black')+ theme(axis.text.x = element_text(angle = 45, hjust = 1))+ theme_economist()+ scale_color_economist()
 
 
 dtm_train_matrix <- as.matrix(dtm_data_corpus)
 
 dtm_train_matrix <- cbind(dtm_train_matrix,Essayset = data$Essayset,min_score = data$min_score,
                           max_score = data$max_score,clarity = data$clarity,
                           coherent = data$coherent
                           )
 
 
 # #-------------  Dataset Renewal  --------------------#  
 
  data_set <- as.data.frame(dtm_train_matrix)
 
 train_set <- data_set[1:nrow(train),]
 test_set  <- data_set[(nrow(train) + 1):nrow(data_set) ,]
 

 #--------------------- Remove Garbage Data ------------------------------#
 rm(Corpus_data,data,data_set,doc_features,dtm_data,dtm_data_corpus,dtm_train_matrix,temp,test,train)
 
 
 
 #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 
 #---------------- Feature Engineering ------------------#
 
 #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 
 
 
 #---------- COnvert Class Outcome to Categorical ---------------------------#
 
 train_set$essay_score <- round(essay_score,digits = 0)
 
 unique(train_set$essay_score)
 
 
 
 #--------------- Encoding essay_score to proper categories to avoid  0 factor level --------------#
 
 train_set$essay_score[train_set$essay_score==0] <- "Score_0"
 train_set$essay_score[train_set$essay_score==1] <- "Score_1"
 train_set$essay_score[train_set$essay_score==2] <- "Score_2"
 train_set$essay_score[train_set$essay_score==3] <- "Score_3"
 
 train_set$essay_score <- factor(train_set$essay_score,levels = c("Score_0","Score_1","Score_2","Score_3"),labels = c("Score_0","Score_1","Score_2","Score_3"))
 
 
 
 
 #----------------- Convert Essayset  to categories --------------------------------#
 
 unique(train_set$Essayset)
 unique(test_set$Essayset)
 
 
 train_set$Essayset <- as.factor(train_set$Essayset)
 test_set$Essayset <- as.factor(test_set$Essayset)
 
 #----------------- Convert Min Score  to categories --------------------------------#
 
 
 unique(train_set$min_score)
 unique(test_set$min_score)
 
 # Remove it as it specifies near zero variance #
 train_set$min_score <- NULL
 test_set$min_score <- NULL
 
 
 
 #----------------- Convert Max Score  to categories --------------------------------#
 
 
 unique(train_set$max_score)
 unique(test_set$max_score)
 
 train_set$max_score <- as.factor(train_set$max_score)
 test_set$max_score <- as.factor(test_set$max_score)
 
 
 #----------------- Convert clarity  to categories --------------------------------#
 
 
 unique(train_set$clarity)
 unique(test_set$clarity)
 
 
 
 train_set$clarity <- as.factor(train_set$clarity)
 test_set$clarity <- as.factor(test_set$clarity)


 #----------------- Convert coherent  to categories --------------------------------#
 
 
 unique(train_set$coherent)
 unique(test_set$coherent)
 

 train_set$coherent <- as.factor(train_set$coherent)
 test_set$coherent <- as.factor(test_set$coherent)
 
 
 
 
 
 
 #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 
 #---------------- Training using H2o ------------------#
 
 #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 
 
 h2o.init()
 
 
 output <- "essay_score"
 input  <- setdiff( names(train_set), output )
 
 train = as.h2o(train_set)
 
 
 # Predictive Modelling for 1 hour
 
 aml <- h2o.automl(y = output,x = input,training_frame = train,nfolds = 10,seed = 123,balance_classes = T,max_runtime_secs = 3600)
 
 
 
 # check the leaderboard
 lb <- aml@leaderboard
 lb
 
 # get model ids  for all models 
 model_ids <- as.data.frame(aml@leaderboard$model_id)[,1]
 
 
 # Get all model stacked ensembled model
 se <- h2o.getModel(grep("StackedEnsemble_AllModels",model_ids,value = TRUE)[1])
 
 metalearner <- h2o.getModel(se@model$metalearner$name)
 
 h2o.varimp(metalearner)
 
 gbm <- h2o.getModel(grep("DeepLearning",model_ids,value=TRUE)[1])
 
 imp  <- as.data.frame(h2o.varimp(gbm))
 
 h2o.varimp_plot(gbm)
 

 #-------------- Make Predictions -------------------------#
 test = as.h2o(test_set)
 
 pred <- h2o.predict(gbm, test)
 
 pred = as.data.frame(pred)
 
 
 submission <- read.csv("test_dataset.csv")
 
 submission <- as.data.frame(submission[,c(1,2)])
 
 submission$essay_score <-  pred$predict

 submission$essay_score <- as.character(submission$essay_score)
 
 submission$essay_score[submission$essay_score=="Score_0"] <- 0
 submission$essay_score[submission$essay_score=="Score_1"] <- 1
 submission$essay_score[submission$essay_score=="Score_2"] <- 2
 submission$essay_score[submission$essay_score=="Score_3"] <- 3 
  
 colnames(submission)[1] <-"id"
 colnames(submission)[2] <-"essay_set"
 
 
 write.csv(submission,"h2o_Automl.csv",row.names = F)
 
 