setwd("C:/Users/acer/Desktop/Employee Attrition Prediction")
training=read.csv("train.csv")
head(training)
library(tidyquant)
testing=read.csv("test.csv")
head(testing)

# change all character data types to factors.
train_data <- training %>%
  mutate_if(is.character, as.factor) %>%
  select(Attrition, everything())

test_data <- testing %>%
  mutate_if(is.character, as.factor) %>%
  select(everything())
############### use SVR model ##################
library(e1071)

svm_model<-svm(Attrition ~ ., data=train_data,epsilon=1,cost=1,gamma=4096)

test_data1=test_data
test_data1$ID=NULL

prediction<- predict(svm_model,newdata = test_data1)
prediction<-as.data.frame(prediction)
Attrition<-prediction$prediction
ID=testing$ID
# Attrition=round(testing$Attrition,digits = 1)
i=0
for (i in 1:length(Attrition))
{
  if (Attrition[i]<0)
  {
    Attrition[i]=0
  }
  
  if (Attrition[i]>1)
  {
    Attrition[i]=1
  }
  
}

solution<-data.frame(ID,Attrition)
write.csv(solution,"solution106_factors.csv",row.names = F)






