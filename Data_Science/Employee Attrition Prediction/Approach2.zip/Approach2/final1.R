setwd("C:/Users/acer/Desktop/Employee Attrition Prediction")
training=read.csv("train.csv")
head(training)
library(tidyquant)
testing=read.csv("test.csv")
head(testing)

attach(training)
str(training)
library(caret)
# machine learning and advanced analytics

library(DMwR)
library(caret)
library(caretEnsemble)
library(pROC)

# natural language processing

# library(msLanguageR) 
library(tm)
library(jiebaR)

# tools

library(httr)
library(XML)
library(jsonlite)

# data visualization

library(scales)
library(ggplot2)
library(wordcloud)


library(dplyr)
library(magrittr)
library(stringr)
library(stringi)
library(readr)




training$Attrition<-as.factor(training$Attrition)
training$promotion_last_5years<-as.factor(training$promotion_last_5years)
training$Work_accident<-as.factor(training$Work_accident)
training$time_spend_company<-as.factor(training$time_spend_company)
training$projects_worked_on<-as.factor(training$projects_worked_on)


# set up the training control.

control <- trainControl(method="repeatedcv", number=3, repeats=1)

# train the model

model <- train(dplyr::select(training, -Attrition), 
               training$Attrition,
               data=training, 
               method="rf", 
               preProcess="scale", 
               trControl=control)
# estimate variable importance

imp <- varImp(model, scale=FALSE)

# select the top-ranking variables.

imp_list <- rownames(imp$importance)[order(imp$importance$Overall, decreasing=TRUE)]

# drop the low ranking variables. Here the last 3 variables are dropped. 

top_var <- 
  imp_list[1:(length(imp_list) - 3)] %>%
  as.character() 
top_var

# select the top ranking variables 
training %<>% select(., one_of(c(top_var, "Attrition")))
testing %<>% select(., one_of(c(top_var, "Attrition")))
library(e1071)
training$Department<-as.numeric(training$Department)
testing$Department<-as.numeric(testing$Department)

SVR_MODEL<-svm(Attrition ~ . , data= training, cost=1, epsilon=1, gamma=8192, probability=TRUE)
predictions<-predict(SVR_MODEL,newdata = testing,probability = T)
ID<-testing$ID
Attrition<-predictions
solution<-data.frame(ID,Attrition)
write.csv(solution,"Final4.csv", row.names = F)