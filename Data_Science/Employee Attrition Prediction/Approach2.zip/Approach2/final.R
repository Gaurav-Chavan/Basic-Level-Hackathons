setwd("C:/Users/acer/Desktop/Employee Attrition Prediction")
training=read.csv("train.csv")
head(training)
library(tidyquant)
testing=read.csv("test.csv")
head(testing)

attach(training)
str(training)
library(ggplot2) #For visualization of data 
library(plotly) # for visualization of data
library(RColorBrewer) #FOr visualization of data
library(e1071)# For SVM(Support vector Modeling)
library(MASS)
library(ISLR)
library(corrgram) # For plotting Correaltion charts 
library(corrplot) # Fpr plotting Correlation charts
library(car) #
library(plyr)
library(dplyr)
library(caTools) # for sample splitting i.e train and test data 
library(ROCR) # for the ROC/ AUC measure
library(pROC) # for the ROC/ AUC measure
library(rattle) # For Visualization of Decision Trees
library(rpart.plot)
library(psych) # For point biserial correlation
library(RColorBrewer)
library(mlr)
library(moments)# To calculate Skewness and Kurtosis 


############################# Convert Variables into Factors ################33
training$Attrition<-as.factor(training$Attrition)
training$promotion_last_5years<-as.factor(training$promotion_last_5years)
training$Work_accident<-as.factor(training$Work_accident)
training$time_spend_company<-as.factor(training$time_spend_company)
training$projects_worked_on<-as.factor(training$projects_worked_on)




hist<-plot_ly(x=training$satisfaction_level,type='histogram')
layout(hist,title = "HR Data - Employee satisfaction_level",xaxis = list(title = "satisfaction_level"),yaxis = list(title = "Count"))


hist<-plot_ly(x=training$time_spend_company,type='histogram')
layout(hist,title = "HR Data - Employee time_spend_company",xaxis = list(title = "average_montly_hours"),yaxis = list(title = "Count"))


hist<-plot_ly(x=training$Work_accident,type='histogram')
layout(hist,title = "HR Data - Employee Work_accident",xaxis = list(title = "Work_accident"),yaxis = list(title = "Count"))

# time_spend_companyis highly skewed towards right and this will affect the model outcome; 
# so we will transform monthly income variable


library(psych)
time_spend_company<-as.numeric((training$time_spend_company))
biserial(training$satisfaction_level,training$Attrition)

# biserial(training$last_evaluation_rating,training$Attrition)
# biserial(training$projects_worked_on,training$Attrition)
# biserial(training$average_montly_hours,training$Attrition)
biserial(training$time_spend_company,training$Attrition)
biserial(training$Work_accident,training$Attrition)
# biserial(training$promotion_last_5years,training$Attrition)
# Department<-as.numeric(training$Department)
# biserial(Department,training$Attrition)
# Salary<-as.numeric(training$salary)
# biserial(Salary,training$Attrition)
# Performing Shapiro-Wilk normality test
library(nortest)
ad.test(time_spend_company)


training$Attrition_M<- training$Attrition

training$Attrition_M <-as.character(training$Attrition_M)

training$Attrition_M[training$Attrition_M=="Yes"] <-"1"
training$Attrition_M[training$Attrition_M=="No"] <-"0"
training$Attrition_M <-as.numeric(training$Attrition_M)
mean(training$Attrition_M)

training$Department<-as.numeric(training$Department)
training$salary<-as.numeric(training$salary)


testing$Department<-as.numeric(testing$Department)
testing$salary<-as.numeric(testing$salary)

###########################svr training model #####################333

library(e1071)
SVR_MODEL<-svm(Attrition_M ~ . , data= training, cost=1, epsilon=1, gamma=8192, probability=TRUE)
predictions<-predict(SVR_MODEL,newdata = testing,probability = T)
ID<-testing$ID
Attrition<-predictions
solution<-data.frame(ID,Attrition)
write.csv(solution,"Final3.csv", row.names = F)
