setwd("D:/Data Science/Hackathons/Hacker Earth/Challenges/ADCAT/Model/churn")

#---------------------- Read Dataset--------------------------------------------------------
data<-read.csv("WA_Customer-Churn.csv",na.strings = "")
#---- check for missing values 
colSums(is.na(data))
# TotalCharges are missing


#----------------------- Missing Value Imputation--------------------------------------------
library(Hmisc)
summary(data$TotalCharges)
# impute with mean value
a<- with(data, impute(TotalCharges, mean))
a<-as.numeric(a)

data$TotalCharges<-a
colSums(is.na(data))


str(data)


#------------------------ Train test Split ----------------------------------------------------
# Divide the data into train and test set (60-40 split)
set.seed(100)
n <- nrow(data)
shuffled_data <- data[sample(n), ]
train_indices <- 1:round(0.6 * n)
train <- shuffled_data[train_indices, ]
test_indices <- (round(0.6 * n) + 1):n
test <- shuffled_data[test_indices, ]


#-------------------------------------------------------------------------------------------
# Data Exploration
str(train)

#find the variables which are numeric and variables which are categorical
classes<-sapply(train,class)
classes<-as.data.frame(classes)
table(classes$classes)

#Factors -16
# Numeric -4
# Class -1



#-------------------- Feature Importance Boruta------------------------------------------------
library(Boruta)

set.seed(123)
boruta.train <- Boruta(Churn~., data = train, doTrace = 2)
print(boruta.train)

plot(boruta.train, xlab = "", xaxt = "n")
lz<-lapply(1:ncol(boruta.train$ImpHistory),function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[,i]),i])
names(lz) <- colnames(boruta.train$ImpHistory)
Labels <- sort(sapply(lz,median))
axis(side = 1,las=2,labels = names(Labels), at = 1:ncol(boruta.train$ImpHistory), cex.axis = 0.7)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

names<-getSelectedAttributes(final.boruta, withTentative = F)

train1<-train[colnames(train) %in% names]
train1$Churn<-train$Churn


actual<-test$Churn

test2<-test[,colnames(test) %in% names]

table(train1$Churn)
# No  Yes 
# 3117 1109 



#------------------------------- Imbalance Data Treatment Using SMOTE------------------------------
# Balance the data using Sampling Techniques

# SMOTE : Synthetic Minority Over-Sampling Technique.


library(caret)
library(DMwR)

sampled_train<-SMOTE(Churn ~.,data = train1)
table(sampled_train$Churn)
# No  Yes 
# 4436 3327 



# create dummy variables-----------------------
library(dummies)
churn <-sampled_train$Churn
sampled_train$Churn<-NULL

sampled_train2 <- dummy.data.frame(sampled_train, sep = ".")
sampled_train2$Churn<-churn


test2<-dummy.data.frame(test2, sep = ".")


ctrl <- trainControl(method = "repeatedcv", repeats = 2,verboseIter = T)

#---------Logistic Regression
logistic_fit <- train(Churn ~ ., data = sampled_train2,method = "glm",metric = "Accuracy",
                      family="binomial",trControl = ctrl)
pred_logistic<-predict(logistic_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_logistic,reference = actual,positive = "Yes")
result


#---------knn 
knn_fit <- train(Churn ~ ., data = sampled_train2,method = "knn",metric = "Accuracy",
                trControl = ctrl)
pred_knn<-predict(knn_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_knn,reference = actual,positive = "Yes")
result




#---------Random FOrest 
rf_fit <- train(Churn ~ ., data = sampled_train2,method = "rf",metric = "Accuracy",
                 trControl = ctrl)
pred_rf<-predict(rf_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_rf,reference = actual,positive = "Yes")
result



#---------Boosted Trees 
gbm_fit <- train(Churn ~ ., data = sampled_train2,method = "gbm",metric = "Accuracy",
                 trControl = ctrl)
pred_gbm<-predict(gbm_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_gbm,reference = actual,positive = "Yes")
result



#---------SVM  
svm_fit <- train(Churn ~ ., data = sampled_train2,method = "svmRadial",metric = "Accuracy",trControl = ctrl)
pred_svm<-predict(svm_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_svm,reference = actual,positive = "Yes")
result

# Accuracy :  0.7913    
# Sensitivity :  0.4395    



#---------Xgboost
xgbTree_fit <- train(Churn ~ ., data = sampled_train2,method = "xgbTree",metric = "Accuracy",trControl = ctrl)
pred_xgbTree<-predict(xgbTree_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_xgbTree,reference = actual,positive = "Yes")
result


# Stacked Model To create Score Model----------------------------------------------------------


# create submodels
library(caretEnsemble)
control <- trainControl(method="repeatedcv", number=5, repeats=2, savePredictions=TRUE, classProbs=TRUE,verboseIter = T)
algorithmList <- c('lda', 'rf', 'xgbTree', 'knn', 'svmRadial')
set.seed(100)
models <- caretList(Churn~., data=sampled_train2, trControl=control, methodList=algorithmList)
results <- resamples(models)
summary(results)
dotplot(results)


# stack using random forest
set.seed(100)
tunegrid <- expand.grid(.mtry=c(sqrt(ncol(sampled_train2))))

stackControl <- trainControl(method="repeatedcv", number=5, repeats=2, savePredictions=TRUE, classProbs=TRUE,verboseIter = T)
stack.rf <- caretStack(models, method="rf", metric="Accuracy", trControl=stackControl)
print(stack.rf)

Accuracy       
0.9211859 

pred<-predict(stack.rf,newdata = test2,type='prob')
churn_score<-pred
churn_score<-as.data.frame(churn_score)

write.csv(churn_score,"churn_score.csv",row.names = F)