setwd("D:/Data Science/Hackathons/Hacker Earth/Challenges/ADCAT/Model/Anomaly")

# Read the data
fraud_data<-read.csv("insurance_claims.csv",sep=",",na.strings = "",header = T)
str(fraud_data)


#------------------------------------------------------------------------------------------------
# remove identifiers or outliers variables
fraud_data$X_c39<-NULL
fraud_data$policy_number<-NULL
fraud_data$incident_location<-NULL

# treat the dates appropriately
str(fraud_data$policy_bind_date)

#convert strings into Date object
fraud_data$policy_bind_date<- as.Date(fraud_data$policy_bind_date,origin ="1970-01-01")
fraud_data$incident_date<- as.Date(fraud_data$incident_date,origin ="1970-01-01")

#-------------------------- Feature Engineering with Dates-----------------------------------
p <- as.POSIXlt(fraud_data$policy_bind_date)
fraud_data$policy_bind_date_yday<-p$yday
fraud_data$policy_bind_date_mday<-p$mday
fraud_data$policy_bind_date_mon<-p$mon
fraud_data$policy_bind_date_wday<-p$wday
fraud_data$policy_bind_date<-NULL

p <- as.POSIXlt(fraud_data$incident_date)
fraud_data$incident_date_yday<-p$yday
fraud_data$incident_date_mday<-p$mday
fraud_data$incident_date_mon<-p$mon
fraud_data$incident_date_wday<-p$wday
fraud_data$incident_date<-NULL


#arrange the columns
fraud_data<-fraud_data[,c(1:34,36:43,35)]





#-----------------------------------------------------------------------------------------
# Divide the data into train and test set (60-40 split)
set.seed(100)
n <- nrow(fraud_data)
shuffled_fraud_data <- fraud_data[sample(n), ]
train_indices <- 1:round(0.6 * n)
train <- shuffled_fraud_data[train_indices, ]
test_indices <- (round(0.6 * n) + 1):n
test <- shuffled_fraud_data[test_indices, ]


#-------------------------------------------------------------------------------------------
# Data Exploration
str(train)

#find the variables which are numeric and variables which are categorical
classes<-sapply(train,class)
classes<-as.data.frame(classes)
table(classes$classes)

#Factors -19
# Numeric -21
# Class -1




#-----------------------------------------------------------------------------------------------
# Imbalanced Data Problem
table(train$fraud_reported)
# N   Y 
# 454 146

# Balance the data using Sampling Techniques

# SMOTE : Synthetic Minority Over-Sampling Technique.


library(caret)
library(DMwR)

sampled_train<-SMOTE(fraud_reported ~.,data = train)
table(sampled_train$fraud_reported)


#----------------------------------------------------------------------------------------------
# Variable Treatment Data: sampled_train
# --------------- Categorical Data-------------------------------------------------------
# Barplpt
# auto_model
# auto_make
# insured_occupation        
# insured_hobbies
library(ggplot2)
# auto_model
print(ggplot(sampled_train, aes(x=fraud_reported))+geom_bar()+facet_grid(.~auto_model)+ggtitle(""))
# set it to dummy

# auto_make
print(ggplot(sampled_train, aes(x=fraud_reported))+geom_bar()+facet_grid(.~auto_make)+ggtitle(""))
# set it to dummy

# insured_occupation
print(ggplot(sampled_train, aes(x=fraud_reported))+geom_bar()+facet_grid(.~insured_occupation)+ggtitle(""))
# set it to dummy

# insured_hobbies
print(ggplot(sampled_train, aes(x=fraud_reported))+geom_bar()+facet_grid(.~insured_hobbies)+ggtitle(""))
# set it to dummy


#-------------- Numerical Data ---------------------------------
library(corrplot)
library(plyr)

# Remove Zero and Near Zero-Variance Predictors
nzv <- nearZeroVar(sampled_train)
#- no near-zero varaince found

# sampled_train <- sampled_train[, -nzv]
# rm(data)


# Identifying numeric variables
numericData <- sampled_train[sapply(sampled_train, is.numeric)]

# Calculate correlation matrix
descrCor <- cor(numericData)

# Print correlation matrix and look at max correlation
print(descrCor)
summary(descrCor[upper.tri(descrCor)])

# Check Correlation Plot
corrplot(descrCor, order = "FPC", method = "color", type = "lower", tl.cex = 0.7, tl.col = rgb(0, 0, 0))

# find attributes that are highly corrected
highlyCorrelated <- findCorrelation(descrCor, cutoff=0.7)

# print indexes of highly correlated attributes
print(highlyCorrelated)

# Indentifying Variable Names of Highly Correlated Variables
highlyCorCol <- colnames(numericData)[highlyCorrelated]

# Print highly correlated attributes
highlyCorCol

# Remove highly correlated variables and create a new dataset
sampled_train2 <- sampled_train[, -which(colnames(sampled_train) %in% highlyCorCol)]
dim(sampled_train2)
test2<-test[,colnames(test) %in% colnames(sampled_train2)]


#-------------------- Feature Importance Boruta------------------------------------------------
library(Boruta)

set.seed(123)
boruta.train <- Boruta(fraud_reported~., data = sampled_train2, doTrace = 2)

plot(boruta.train, xlab = "", xaxt = "n")
lz<-lapply(1:ncol(boruta.train$ImpHistory),function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[,i]),i])
names(lz) <- colnames(boruta.train$ImpHistory)
Labels <- sort(sapply(lz,median))
axis(side = 1,las=2,labels = names(Labels), at = 1:ncol(boruta.train$ImpHistory), cex.axis = 0.7)

#------------------------------------------------------------------------------------------------
# Predictive Modelling
# Algorithms to use:

# 1. Logistic Regression
# 2. Decision tree
# 3. K-nn
# 4. Naive Bayes
# 5. svm
# 6. lda

actual<-test2$fraud_reported
test2$fraud_reported<-NULL


# create dummy variables
library(dummies)
fraud_reported<-sampled_train2$fraud_reported
sampled_train2$fraud_reported<-NULL

sampled_train2 <- dummy.data.frame(sampled_train2, sep = ".")
sampled_train2$fraud_reported<-fraud_reported


test2<-dummy.data.frame(test2, sep = ".")



ctrl <- trainControl(method = "repeatedcv", repeats = 2,verboseIter = T)

#---------Logistic Regression
logistic_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "glm",metric = "Accuracy",
                  family="binomial",trControl = ctrl)
pred_logistic<-predict(logistic_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_logistic,reference = actual,positive = "Y")
result

# Accuracy : 0.6875 
# Sensitivity : 0.5545 




#---------knn Algorithm
knn_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "knn",metric = "Accuracy",trControl = ctrl)
pred_knn<-predict(knn_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_knn,reference = actual,positive = "Y")
result

# Accuracy : 0.655  
# Sensitivity :  0.2277 



#---------Random Forest -Bagging 
rf_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "rf",metric = "Accuracy",trControl = ctrl)
pred_rf<-predict(rf_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_rf,reference = actual,positive = "Y")
result

# Accuracy : 0.8325  
# Sensitivity : 0.8713    


#---------Boosted Trees 
gbm_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "gbm",metric = "Accuracy",trControl = ctrl)
pred_gbm<-predict(gbm_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_gbm,reference = actual,positive = "Y")
result

# Accuracy : 0.8175   
# Sensitivity :  0.6832  

#---------SVM  
svm_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "svmRadial",metric = "Accuracy",trControl = ctrl)
pred_svm<-predict(svm_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_svm,reference = actual,positive = "Y")
result

# Accuracy :  0.775    
# Sensitivity :  0.6832    



#---------Xgboost
xgbTree_fit <- train(fraud_reported ~ ., data = sampled_train2,method = "xgbTree",metric = "Accuracy",trControl = ctrl)
pred_xgbTree<-predict(xgbTree_fit,newdata = test2)

# summary(logistic_fit)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_xgbTree,reference = actual,positive = "Y")
result

# Accuracy :  0.7925   
# Sensitivity :  0.6832  




#--------------- Score Model-------------------------------------------------
#---------Random Forest -Bagging  

control <- trainControl(method="repeatedcv", number=5,repeats = 2 ,search="grid",classProbs = TRUE,verboseIter = T,summaryFunction = twoClassSummary)
tunegrid <- expand.grid(.mtry=c(sqrt(ncol(sampled_train2))))
modellist <- list()
for (ntree in c(500, 1000, 1500)) {
  set.seed(100)
  fit <- train(fraud_reported~., data=sampled_train2, method="rf", metric="ROC", tuneGrid=tunegrid, trControl=control, ntree=ntree)
  key <- toString(ntree)
  modellist[[key]] <- fit
}
# compare results
results <- resamples(modellist)
summary(results)
dotplot(results)

# Accuracy Improved when Trees were 100
pred_rf<-predict(fit,newdata = test2,type="prob")

# Score's --------------------------- pred_rf
score<-pred_rf$Y
score_model<-data.frame(score=score,class=actual)
