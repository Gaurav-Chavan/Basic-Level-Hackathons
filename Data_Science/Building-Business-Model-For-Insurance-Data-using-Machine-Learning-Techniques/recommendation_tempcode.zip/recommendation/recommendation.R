setwd("D:/Data Science/Hackathons/Hacker Earth/Challenges/ADCAT/Model/group")

#Load Dataset
df <-read.csv("caravan-insurance-challenge.csv")

library(ggplot2) #Data Visualisation
library(dplyr) #Renaming
library(ROSE) #Sampling
library(caret) #Partitioning

#---------- Data Description and Exploratory Data Analysis-------------------------------------------------

names(df)

#Class label freq 
classLabelFreq <- data.frame(df$CARAVAN)
classLabelFreq$df.CARAVAN <- as.factor(df$CARAVAN)

#Class label Distribution Plot 
ggplot(classLabelFreq,aes(x=df.CARAVAN)) + geom_bar() + labs(x="CARAVAN")

#Size of each factor level 
table(df$CARAVAN)


#Cust main type
custMainType <- data.frame(df$MOSHOOFD,df$CARAVAN)
custMainType$df.MOSHOOFD <- as.factor(custMainType$df.MOSHOOFD)
custMainType$df.CARAVAN <- as.factor(custMainType$df.CARAVAN)

#Plot of Customer Main Type
plot<-ggplot(custMainType,aes(x=reorder(df.MOSHOOFD,df.MOSHOOFD,function(x)-length(x)),fill=df.CARAVAN))
plot<-plot + geom_bar() 
plot<-plot + labs(x="Customer Main Type")
plot                         



#When Caravan is true
wantsCaravan <- df[df$CARAVAN==1,]
wantsCaravan$MOSHOOFD <- as.factor(wantsCaravan$MOSHOOFD)
wantsCaravan$MOSTYPE <- as.factor(wantsCaravan$MOSTYPE)

#Plot of Customer Main Type where wants caravan
plot<-ggplot(wantsCaravan,aes(x=reorder(MOSHOOFD,MOSHOOFD,function(x)-length(x))))
plot<-plot + geom_bar()
plot<-plot + labs(x="Customer Main Type")
plot

#Max and Min
mainCustType = table(wantsCaravan$MOSHOOFD)
names(which.max(mainCustType))
names(which.min(mainCustType))


#------------------ Refactoring Levels and Labelling them Properly----------------------------------- 
#Customer Subtype Refactor
df$MOSTYPE <- factor(df$MOSTYPE,
                     levels=c(1:41),
                     labels=c("High Income, expensive child",
                              "Very Important Provincials",
                              "High status seniors",
                              "Affluent senior apartments",
                              "Mixed seniors",
                              "Career and childcare",
                              "Dinki's (Double income no kids)",
                              "Middle class families",
                              "Modern, complete families",
                              "Stable family","Family starters",
                              "Affluent young families",
                              "Young all american family",
                              "Junior cosmopolitans",
                              "Senior cosmopolitans",
                              "Students in apartments",
                              "Fresh masters in the city",
                              "Single youth",
                              "Suburban youth",
                              "Ethnically diverse",
                              "Young urban have-nots",
                              "Mixed apartment dwellers",
                              "Young and rising", 
                              "Young, low educated", 
                              "Yound seniros in the city",
                              "Own home elderly",
                              "Seniors in apartments",
                              "Residential elderly",
                              "Porchless seniors: no front yard",
                              "Religious elderly singles",
                              "Low income catholics",
                              "Mixed seniors2",
                              "Lower class large families",
                              "Large family,employed child",
                              "Village families",
                              "Couples with teens 'Married with children'",
                              "Mixed small town dwellers",
                              "Traditional families",
                              "Large religous families",
                              "Large family farms",
                              "Mixed rurals"))

#Average Age Refactor
df$MGEMLEEF <- factor(df$MGEMLEEF,
                      levels=c(1:6),
                      labels=c("20-30 years",
                               "30-40 years",
                               "40-50 years",
                               "50-60 years",
                               "60-70 years",
                               "70-80 years")) 

#Custom Main Type Refactor

df$MOSHOOFD <- factor(df$MOSHOOFD,
                      levels=(1:10),
                      labels=c("Successful hedonists",
                               "Driven Growers",
                               "Average Family",
                               "Career Loners",
                               "Living well",
                               "Cruising Seniors",
                               "Retired and Religious",
                               "Family with grown ups",
                               "Conservatie Families",
                               "Farmers"))

#Percentages Refactor
# Percentages in each group, per postal code
for (i in which(colnames(df)=="MGODRK"):which(colnames(df)=="MKOOPKLA")){
  df[,i] <- factor(df[,i],
                   levels=c(0:9),
                   labels=c("0%",
                            "1-10%",
                            "11-23%",
                            "24-36%",
                            "37-49%",
                            "50-62%",
                            "63-75%",
                            "76-88%",
                            "89-99%",
                            "100%"))
}

#Number of Refactor
# Total number of variable in postal code 
# Contribution private third party insurance
for (i in which(colnames(df)=="PWAPART"):which(colnames(df)=="ABYSTAND")){
  df[,i] <- factor(df[,i],
                   levels=c(0:9),
                   labels=c("0",
                            "1-49",
                            "50-99",
                            "100-199",
                            "200-499",
                            "500-999",
                            "1000-4999",
                            "5000-9999",
                            "10,000-19,999",
                            ">=20,000"))
}


#Set caravan label as factor 
df$CARAVAN <- factor(df$CARAVAN,levels=c("0","1"))



#------------------- Class label rename MOSHOOFD tocustomer group  ------------------------------------------------------
data<-df
colnames(data)[colnames(data)=='MOSHOOFD']<-'Customer_group'

#----- adjust columns
data<-data[,c(1:5,7:87,6)]

str(data)

#------------------ Create Insurance Label According to life stages ---------------------

# Retired and Religious<-  Health, Vehicle, Fire, Life_Whole   60-70,70-80

# Average Family <-        Vehicle, Health, Life_Whole          # "40-50 years"
# Farmers<-               Vehicle, Fire, Health               # "40-50 years",

# Family with grown ups<- Vehicle, Life_Term                   # "50-60 years", 



# Conservatie Families<-  Vehicle, Health, Life_Whole          # "30-40 years",

# Driven Growers<-        Vehicle, Health, Life_Term          # "20-30 years",


data$INSTYPE<-NA

a1<-data[(data$MGEMLEEF=='60-70 years' |data$MGEMLEEF=='70-80 years'),][1:94,]
a1$INSTYPE<-'HEALTH'

a2<-data[(data$MGEMLEEF=='60-70 years' |data$MGEMLEEF=='70-80 years'),][95:188,]
a2$INSTYPE<-'VEHICLE'


a3<-data[data$MGEMLEEF=='60-70 years' |data$MGEMLEEF=='70-80 years',][189:282,]
a3$INSTYPE<-'Fire'


a4<-data[data$MGEMLEEF=='60-70 years' |data$MGEMLEEF=='70-80 years',][283:378,]
a4$INSTYPE<-'Life_Whole'

#1288,2577,3865,5154
a5<-data[data$MGEMLEEF=='40-50 years',][1:1288,]
a5$INSTYPE<-'VEHICLE'

a6<-data[data$MGEMLEEF=='40-50 years',][1289:2577,]
a6$INSTYPE<-'Health'

a7<-data[data$MGEMLEEF=='40-50 years',][2578:3865,]
a7$INSTYPE<-'Fire'

a8<-data[data$MGEMLEEF=='40-50 years',][3866:5154,]
a8$INSTYPE<-'Life_Whole'

a9<-data[data$MGEMLEEF=='20-30 years',][1:34,]
a9$INSTYPE<-'VEHICLE'

a10<-data[data$MGEMLEEF=='20-30 years',][35:68,]
a10$INSTYPE<-'Health'

a11<-data[data$MGEMLEEF=='20-30 years',][69:104,]
a11$INSTYPE<-'Life_Term'

a12<-data[data$MGEMLEEF=='30-40 years',][1:803,]
a12$INSTYPE<-'Life_Term'

a13<-data[data$MGEMLEEF=='30-40 years',][804:1606,]
a13$INSTYPE<-'Health'

a14<-data[data$MGEMLEEF=='30-40 years',][1607:2409,]
a14$INSTYPE<-'VEHICLE'

data1<-rbind(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14)
data2<-data1[complete.cases(data1),]
rm(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,data,data1)



#---------------------Split data into train and test----------------------------------
data2$ORIGIN<-NULL
#-----------------------------------------------------------------------------------------
# Divide the data into train and test set (60-40 split)
set.seed(100)
n <- nrow(data2)
shuffled_data <- data2[sample(n), ]
train_indices <- 1:round(0.6 * n)
train <- shuffled_data[train_indices, ]
test_indices <- (round(0.6 * n) + 1):n
test <- shuffled_data[test_indices, ]

table(train$INSTYPE)
table(test$INSTYPE)


#---------------------- Feature Removal--------------------------------------------------
# Remove Zero and Near Zero-Variance Predictors
nzv <- nearZeroVar(train)

sampled_train1 <- train[, -nzv]
test1<-test[colnames(test) %in% colnames(sampled_train1)]

str(sampled_train1)
sampled_train1$INSTYPE<-factor(sampled_train1$INSTYPE)

test1$INSTYPE<-factor(test1$INSTYPE)



#----------------------  Feature Importance : Boruta------------------------------------

library(Boruta)

set.seed(123)
boruta.train <- Boruta(INSTYPE~., data = sampled_train1, doTrace = 2)
print(boruta.train)


plot(boruta.train, xlab = "", xaxt = "n")
lz<-lapply(1:ncol(boruta.train$ImpHistory),function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[,i]),i])
names(lz) <- colnames(boruta.train$ImpHistory)
Labels <- sort(sapply(lz,median))
axis(side = 1,las=2,labels = names(Labels), at = 1:ncol(boruta.train$ImpHistory), cex.axis = 0.7)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)


names<-getSelectedAttributes(final.boruta, withTentative = F)

train1<-sampled_train1[colnames(sampled_train1) %in% names]
train1$INSTYPE<-sampled_train1$INSTYPE


actual<-test1$INSTYPE

test2<-test1[,colnames(test1) %in% names]

table(train1$INSTYPE)
# No  Yes 
# 3117 1109



#------------------------------- Imbalance Data Treatment Using SMOTE------------------------------
# Balance the data using Sampling Techniques

# SMOTE : Synthetic Minority Over-Sampling Technique.


library(caret)
library(DMwR)

sampled_train<-SMOTE(INSTYPE~.,data = train1)
table(sampled_train$INSTYPE)



# create dummy variables-----------------------
library(dummies)
INSTYPE <-sampled_train$INSTYPE
sampled_train$INSTYPE<-NULL

sampled_train2 <- dummy.data.frame(sampled_train, sep = ".")
sampled_train2$INSTYPE<-INSTYPE


test2<-dummy.data.frame(test2, sep = ".")


ctrl <- trainControl(method = "repeatedcv",number = 5, repeats = 2,verboseIter = T)

#---------XGBOOST 
logistic_fit <- train(INSTYPE ~ ., data = sampled_train2,method = "xgbTree",metric = "Accuracy",trControl = ctrl)
pred_logistic<-predict(logistic_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_logistic,reference = actual)
result





#-------------- Score
score<-predict(ogistic_fit,newdata = test2,type='prob')
score<-as.data.frame(score)
write.csv(score,"recommendation_score.csv")


