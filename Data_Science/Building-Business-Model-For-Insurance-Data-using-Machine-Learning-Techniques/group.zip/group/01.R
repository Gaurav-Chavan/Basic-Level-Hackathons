setwd("D:/Data Science/Hackathons/Hacker Earth/Challenges/ADCAT/Model/group")

#Load Dataset
df <-read.csv("caravan-insurance-challenge.csv")

library(ggplot2) #Data Visualisation
library(dplyr) #Renaming
library(ROSE) #Sampling
library(caret) #Partitioning