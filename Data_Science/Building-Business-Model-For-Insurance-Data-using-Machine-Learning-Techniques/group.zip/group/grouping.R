setwd("D:/Data Science/Hackathons/Hacker Earth/Challenges/ADCAT/Model/group")

#Load Dataset
df <-read.csv("caravan-insurance-challenge.csv")

library(ggplot2) #Data Visualisation
library(dplyr) #Renaming
library(ROSE) #Sampling
library(caret) #Partitioning

#---------- Data Description and Exploratory Data Analysis-------------------------------------------------

names(df)

#Class label freq 
classLabelFreq <- data.frame(df$CARAVAN)
classLabelFreq$df.CARAVAN <- as.factor(df$CARAVAN)

#Class label Distribution Plot 
ggplot(classLabelFreq,aes(x=df.CARAVAN)) + geom_bar() + labs(x="CARAVAN")

#Size of each factor level 
table(df$CARAVAN)


#Cust main type
custMainType <- data.frame(df$MOSHOOFD,df$CARAVAN)
custMainType$df.MOSHOOFD <- as.factor(custMainType$df.MOSHOOFD)
custMainType$df.CARAVAN <- as.factor(custMainType$df.CARAVAN)

#Plot of Customer Main Type
plot<-ggplot(custMainType,aes(x=reorder(df.MOSHOOFD,df.MOSHOOFD,function(x)-length(x)),fill=df.CARAVAN))
plot<-plot + geom_bar() 
plot<-plot + labs(x="Customer Main Type")
plot                         



#When Caravan is true
wantsCaravan <- df[df$CARAVAN==1,]
wantsCaravan$MOSHOOFD <- as.factor(wantsCaravan$MOSHOOFD)
wantsCaravan$MOSTYPE <- as.factor(wantsCaravan$MOSTYPE)

#Plot of Customer Main Type where wants caravan
plot<-ggplot(wantsCaravan,aes(x=reorder(MOSHOOFD,MOSHOOFD,function(x)-length(x))))
plot<-plot + geom_bar()
plot<-plot + labs(x="Customer Main Type")
plot

#Max and Min
mainCustType = table(wantsCaravan$MOSHOOFD)
names(which.max(mainCustType))
names(which.min(mainCustType))


#------------------ Refactoring Levels and Labelling them Properly----------------------------------- 
#Customer Subtype Refactor
df$MOSTYPE <- factor(df$MOSTYPE,
                     levels=c(1:41),
                     labels=c("High Income, expensive child",
                              "Very Important Provincials",
                              "High status seniors",
                              "Affluent senior apartments",
                              "Mixed seniors",
                              "Career and childcare",
                              "Dinki's (Double income no kids)",
                              "Middle class families",
                              "Modern, complete families",
                              "Stable family","Family starters",
                              "Affluent young families",
                              "Young all american family",
                              "Junior cosmopolitans",
                              "Senior cosmopolitans",
                              "Students in apartments",
                              "Fresh masters in the city",
                              "Single youth",
                              "Suburban youth",
                              "Ethnically diverse",
                              "Young urban have-nots",
                              "Mixed apartment dwellers",
                              "Young and rising", 
                              "Young, low educated", 
                              "Yound seniros in the city",
                              "Own home elderly",
                              "Seniors in apartments",
                              "Residential elderly",
                              "Porchless seniors: no front yard",
                              "Religious elderly singles",
                              "Low income catholics",
                              "Mixed seniors2",
                              "Lower class large families",
                              "Large family,employed child",
                              "Village families",
                              "Couples with teens 'Married with children'",
                              "Mixed small town dwellers",
                              "Traditional families",
                              "Large religous families",
                              "Large family farms",
                              "Mixed rurals"))

#Average Age Refactor
df$MGEMLEEF <- factor(df$MGEMLEEF,
                      levels=c(1:6),
                      labels=c("20-30 years",
                               "30-40 years",
                               "40-50 years",
                               "50-60 years",
                               "60-70 years",
                               "70-80 years")) 

#Custom Main Type Refactor

df$MOSHOOFD <- factor(df$MOSHOOFD,
                      levels=(1:10),
                      labels=c("Successful hedonists",
                               "Driven Growers",
                               "Average Family",
                               "Career Loners",
                               "Living well",
                               "Cruising Seniors",
                               "Retired and Religious",
                               "Family with grown ups",
                               "Conservatie Families",
                               "Farmers"))

#Percentages Refactor
# Percentages in each group, per postal code
for (i in which(colnames(df)=="MGODRK"):which(colnames(df)=="MKOOPKLA")){
  df[,i] <- factor(df[,i],
                   levels=c(0:9),
                   labels=c("0%",
                            "1-10%",
                            "11-23%",
                            "24-36%",
                            "37-49%",
                            "50-62%",
                            "63-75%",
                            "76-88%",
                            "89-99%",
                            "100%"))
}

#Number of Refactor
# Total number of variable in postal code 
# Contribution private third party insurance
for (i in which(colnames(df)=="PWAPART"):which(colnames(df)=="ABYSTAND")){
  df[,i] <- factor(df[,i],
                   levels=c(0:9),
                   labels=c("0",
                            "1-49",
                            "50-99",
                            "100-199",
                            "200-499",
                            "500-999",
                            "1000-4999",
                            "5000-9999",
                            "10,000-19,999",
                            ">=20,000"))
}


#Set caravan label as factor 
df$CARAVAN <- factor(df$CARAVAN,levels=c("0","1"))



#------------------- Class label rename MOSHOOFD tocustomer group  ------------------------------------------------------
data<-df
colnames(data)[colnames(data)=='MOSHOOFD']<-'Customer_group'

#----- adjust columns
data<-data[,c(1:5,7:87,6)]

str(data)



#---------------------Split data into train and test----------------------------------
train<-data[data$ORIGIN=='train',] #5822 training samples
test<-data[data$ORIGIN=='test',]   #4000 test samples


sampled_train<-train


#---------------------- Feature Removal--------------------------------------------------
# Remove Zero and Near Zero-Variance Predictors
nzv <- nearZeroVar(sampled_train)

sampled_train1 <- sampled_train[, -nzv]
test1<-test[colnames(test) %in% colnames(sampled_train1)]

#----------------------  Feature Importance : Boruta------------------------------------

library(Boruta)

set.seed(123)
boruta.train <- Boruta(Customer_group~., data = sampled_train1, doTrace = 2)
print(boruta.train)


plot(boruta.train, xlab = "", xaxt = "n")
lz<-lapply(1:ncol(boruta.train$ImpHistory),function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[,i]),i])
names(lz) <- colnames(boruta.train$ImpHistory)
Labels <- sort(sapply(lz,median))
axis(side = 1,las=2,labels = names(Labels), at = 1:ncol(boruta.train$ImpHistory), cex.axis = 0.7)

final.boruta <- TentativeRoughFix(boruta.train)
print(final.boruta)

names<-getSelectedAttributes(final.boruta, withTentative = F)

sampled_train2<-sampled_train1[colnames(sampled_train1) %in% names]
sampled_train2$Customer_group<-sampled_train1$Customer_group

actual<-test1$Customer_group

test2<-test1[,colnames(test1) %in% names]

table(sampled_train2$Customer_group)
# Career Loners
# Unbalanced Data

#-------------------- Data Balancing : SMOTE-------------------------------------------

library(DMwR)

sampled_train<-SMOTE(Customer_group ~.,data = sampled_train2)
table(sampled_train$Customer_group)


ctrl <- trainControl(method = "repeatedcv", repeats = 2,verboseIter = T)

#---------GBM Algorithm
gbm_fit <- train(Customer_group ~ ., data = sampled_train,method = "gbm",metric = "Accuracy",trControl = ctrl)
pred_gbm<-predict(gbm_fit,newdata = test2)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_gbm,reference = actual)
result

# Accuracy : 0.6235  



#---------Random Forest -Bagging 
rf_fit <- train(Customer_group ~ ., data = sampled_train,method = "rf",metric = "Accuracy",trControl = ctrl)
pred_rf<-predict(rf_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_rf,reference = actual)
result

# Accuracy : 0.7748  


#---------SVM Trees 
svm_fit <- train(Customer_group ~ ., data = sampled_train,method = "svmRadial",metric = "Accuracy",trControl = ctrl)
pred_svm<-predict(svm_fit,newdata = test2)


#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_svm,reference = actual)
result

# Accuracy :  0.4882     
   


#---------Xgboost
xgbTree_fit <- train(Customer_group ~ ., data = sampled_train,method = "xgbTree",metric = "Accuracy",trControl = ctrl)
pred_xgbTree<-predict(xgbTree_fit,newdata = test2)

#------------ COnfusion Matrix -------------------------------------------

result<-confusionMatrix(data = pred_xgbTree,reference = actual)
result

# Accuracy :  0.9262   






